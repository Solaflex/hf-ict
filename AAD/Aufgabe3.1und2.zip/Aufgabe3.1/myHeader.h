
class CoinCombination {
public:
	static void printCoinCombination(double value, const double *coins, const int ARRAY_SIZE);
};