// Aufgabe3.2

#include <iostream>
#include <string>
#include <C:\git\RunProject\RunProject\myHeader.h>


using namespace std;


int main()
{

	string myPalindrome = "Otto";
	StringUtil myStringTester;

	cout << myStringTester.isPalindrome(myPalindrome) << endl;


	system("PAUSE");

	return 0;

}



