#include <string>

class StringUtil {
public:
	static bool isPalindrome(std::string input);
};